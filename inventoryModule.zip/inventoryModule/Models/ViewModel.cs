﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ERPSystem.Models
{
    public class ViewModel
    {
        public DateTime inv_InDate { get; set; }
        public int prod_Id { get; set; }
        public string prod_Name { get; set; }
        public string prod_Description { get; set; }
        public int inv_QOH { get; set; }
        public string ProdUnit { get; set; }
        public double ProdPriceUnit { get; set; }
        public double ProdTotalPrice { get; set; }
        public int isActive { get; set; }

    }
}