﻿using ERPSystem.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ERPSystem.Data
{
    internal class ProductDAO
    {
        private string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Zak\source\repos\Keken20\ERPSystem\ERPSystem\App_Data\FullDB.mdf;Integrated Security=True";
        
        public List<ProductModel> FetchAll()
        {
            List<ProductModel> productList = new List<ProductModel>();
            using (SqlConnection connectDB = new SqlConnection(connString))
            {
                connectDB.Open();
                string sqlQuery = "SELECT * FROM Product WHERE ProdIsActive = 1";
                SqlCommand cmd = new SqlCommand(sqlQuery, connectDB);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ProductModel products = new ProductModel();
                        products.prod_Id = Convert.ToInt32(reader["ProdId"]);
                        products.prod_Name = reader["prodName"].ToString();
                        products.prod_Description = reader["prodDescription"].ToString();
                        products.inDate = Convert.ToDateTime(reader["ProdCreatedAt"]);
                        //products.upDate = Convert.ToDateTime(reader["ProdUpdatedAt"]);
                        //products.prodCategoryID = Convert.ToInt32(reader["ProdCategoryId"]);
                        //products.supplierID = Convert.ToInt32(reader["SupplierID"]);
                        products.isActive = Convert.ToInt32(reader["ProdIsActive"]);
                        productList.Add(products);
                    }
                }
            }
            return productList;
        }

        public ProductModel FetchOne(int ID)
        {
            using (SqlConnection ConnectDB = new SqlConnection(connString))
            {
                string sqlQuery = "SELECT * FROM PRODUCT WHERE prodId = @id";

                SqlCommand cmd = new SqlCommand(sqlQuery, ConnectDB);

                cmd.Parameters.Add("@id", System.Data.SqlDbType.Int).Value = ID;

                ConnectDB.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                ProductModel product= new ProductModel();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        product.prod_Id = Convert.ToInt32(reader["ProdId"]);
                        product.prod_Name = reader["prodName"].ToString();
                        product.prod_Description = reader["prodDescription"].ToString();
                        product.inDate = Convert.ToDateTime(reader["ProdCreatedAt"]);
                        //product.upDate = Convert.ToDateTime(reader["ProdUpdatedAt"]);
                        //product.prodCategoryID = Convert.ToInt32(reader["ProdCategoryId"]);
                        //product.supplierID = Convert.ToInt32(reader["SupplierID"]);
                        product.isActive = Convert.ToInt32(reader["ProdIsActive"]);

                    }
                }
                return product;
            }
        }

        public int CreateOrUpdate(ProductModel productModel)
        {
            using (SqlConnection ConnectDB = new SqlConnection(connString))
            {
                ConnectDB.Open();
                try
                {
                    string sqlQuery = "";
                    if (productModel.prod_Id <= 0)
                    {
                        sqlQuery = "INSERT INTO PRODUCT(ProdName, ProdDescription, ProdCreatedAt, ProdIsActive) values(@pName, @Description, @indate, @active)";
                        //sqlQuery = "INSERT INTO PRODUCT values(@pName, @Description, @indate, @update,@active, @pcatId, @supId)";
                    }
                    else
                    {
                        sqlQuery = "UPDATE PRODUCT SET prodName = @pName, prodDescription = @Description, " +
                            "ProdUpdatedAt = @update WHERE prodId = @pID";
                        //sqlQuery = "UPDATE PRODUCT SET prodName = @pName, prodDescription = @Description, " +
                        //    "ProdUpdatedAt = @update, ProdcategoryId = @pcatId, SupplierId = @supId WHERE prodId = @pID";
                    }

                    SqlCommand cmd = new SqlCommand(sqlQuery, ConnectDB);
                    cmd.Parameters.AddWithValue("@pID", productModel.prod_Id);
                    cmd.Parameters.AddWithValue("@pName", productModel.prod_Name);
                    cmd.Parameters.AddWithValue("@Description", productModel.prod_Description);
                    cmd.Parameters.AddWithValue("@indate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@update", DateTime.Now);
                    //cmd.Parameters.AddWithValue("@pcatId", productModel.prodCategoryID);
                    //cmd.Parameters.AddWithValue("@supId", productModel.supplierID);
                    cmd.Parameters.AddWithValue("@active", 1);

                    int productID = cmd.ExecuteNonQuery();
                    return productID;
                }
                catch (Exception)
                {
                    return -1;
                }
               
            }
        }



        internal int itemDelete(int ID)
        {
            using (SqlConnection ConnectDB = new SqlConnection(connString))
            {
                string sqlQuery = "UPDATE PRODUCT set ProdIsActive = @deactivate where prodid = @ID";
                SqlCommand cmd = new SqlCommand(sqlQuery, ConnectDB);
                cmd.Parameters.AddWithValue("@ID", ID);
                cmd.Parameters.AddWithValue("@deactivate", 0);
                ConnectDB.Open();
                int deleteID = cmd.ExecuteNonQuery();

                return deleteID;
            }
        }

        internal List<ProductModel> SearchKey(string searchPhrase)
        {
            List<ProductModel> returnProducts = new List<ProductModel>();

            using (SqlConnection ConnectDB = new SqlConnection(connString))
            {
                ConnectDB.Open();

                string sqlQuery = "SELECT PRODID, PRODNAME, PRODDESCRIPTION, PRODCATEGORYID, SUPPLIERID, PRODISACTIVE FROM PRODUCT WHERE (PRODID LIKE '%'+@KEY+'%' OR " +
                    "PRODDESCRIPTION LIKE '%'+@KEY+'%' OR PRODCATEGORYID LIKE '%'+@KEY+'%' OR SUPPLIERID LIKE '%'+@KEY+'%' OR PRODISACTIVE LIKE @KEY) AND PRODISACTIVE = 1";

                SqlCommand cmd = new SqlCommand(sqlQuery, ConnectDB);
                cmd.Parameters.AddWithValue("@KEY", searchPhrase);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ProductModel products = new ProductModel();
                        products.prod_Id = Convert.ToInt32(reader["ProdId"]);
                        products.prod_Name = reader["prodName"].ToString();
                        products.prod_Description = reader["prodDescription"].ToString();
                        //products.inDate = Convert.ToDateTime(reader["ProdCreatedAt"]);
                        //products.upDate = Convert.ToDateTime(reader["ProdUpdatedAt"]);
                        products.prodCategoryID = reader["ProdCategoryId"] != DBNull.Value ? Convert.ToInt32(reader["ProdCategoryId"]) : 0;
                        products.prodCategoryID = reader["ProdCategoryId"] != DBNull.Value ? Convert.ToInt32(reader["ProdCategoryId"]) : 0;
                        products.isActive = Convert.ToInt32(reader["ProdIsActive"]);
                        returnProducts.Add(products);
                    }
                }
            }
            return returnProducts;
        }
    }


}