﻿using ERPSystem.Data;
using ERPSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ERPSystem.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult Index()
        {

            List<ProductModel> products = new List<ProductModel>();
            ProductDAO productDAO = new ProductDAO();
            products = productDAO.FetchAll();

            return View("Index", products);
        }
        public ActionResult productCreate()
        {
            //List<ProductModel> baligya = new List<ProductModel>();
            //using (SqlConnection ConnectDB = new SqlConnection(connString))
            //{
            //    ConnectDB.Open();
            //    string sqlQuery = "SELECT * FROM product";
            //    SqlCommand cmd = new SqlCommand(sqlQuery, ConnectDB);
            //    DataTable dtbl = new DataTable();
            //    SqlDataAdapter sda = new SqlDataAdapter(cmd);
            //    sda.Fill(dtbl);
            //    foreach (DataRow row in dtbl.Rows)
            //    {
            //        ProductModel baligyamodel = new ProductModel
            //        {
            //            prod_Id = Convert.ToInt32(row["prod_id"]),
            //            prod_Name = row["prod_Name"].ToString(),
            //        };
            //        baligya.Add(baligyamodel);
            //    }
            //    ViewBag.prodName = new SelectList(baligya, "prod_Name", "prod_Name");
            //}
            return View("Create");
        }

        [HttpPost]
        public ActionResult ProcessCreate(ProductModel productModel)
        {
            ProductDAO productDAO = new ProductDAO();
            productDAO.CreateOrUpdate(productModel);

            List<ProductModel> products = new List<ProductModel>();
            products = productDAO.FetchAll();
            return View("Index", products);
        }


        public ActionResult Delete(int ID)
        {
            ProductDAO productDAO = new ProductDAO();
            productDAO.itemDelete(ID);

            List<ProductModel> items = productDAO.FetchAll();
            return View("Index", items);
        }

        public ActionResult Edit(int ID)
        {
            ProductDAO productDAO = new ProductDAO();
            ProductModel products = productDAO.FetchOne(ID);
            return View("Edit", products);
        }

        [HttpPost]
        public ActionResult ProcessEdit(ProductModel productModel)
        {
            ProductDAO productDAO = new ProductDAO();
            productDAO.CreateOrUpdate(productModel);

            List<ProductModel> products = new List<ProductModel>();
            products = productDAO.FetchAll();
            return RedirectToAction("Index", products);
        }

        public ActionResult Search(string searchPhrase)
        {
            ProductDAO productDAO = new ProductDAO();
            List<ProductModel> searchResults = productDAO.SearchKey(searchPhrase);
            return View("Index", searchResults);
        }


    }
}